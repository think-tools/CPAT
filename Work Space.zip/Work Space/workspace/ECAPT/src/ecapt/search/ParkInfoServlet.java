package ecapt.search;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ParkInfoServlet
 */
@WebServlet("/ParkInfoServlet")
public class ParkInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParkInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String parkName = request.getParameter("parkname");
		out.println("<h3>Reading QueryString data using 'String getParameter(String name)' method: </h3>");
		out.println("<div>");
		out.println("<p>Park Name:"+ parkName+"</p>");
		out.println("</div>");
		out.println("<h3>Reading QueryString data using 'Enumeratoration getParameterNames()' method: </h3>");
		Enumeration<String> paraNames = request.getParameterNames();
		out.println("<div>");
		while (paraNames.hasMoreElements())
		{
			String paraName = paraNames.nextElement();
			String paraValue = request.getParameter("parkname");
			out.println("<p>"+paraName+":"+paraValue+"</p>");
		}
		out.println("</div>");
		Map<String, String[]> paraMap = request.getParameterMap();
		Set<String> paraNamesSet = paraMap.keySet();
		out.println("<h3>Reading QueryString data using 'Map getParameterMap()' method: </h3>");
		out.println("<div>");
		for(String paraName: paraNamesSet)
		{
			String[] paraValues = paraMap.get(paraName);
			out.println("<p>"+paraName+":");
			for(int i = 0; i<paraValues.length;i++)
			{
				out.println(paraValues[i]);
			}
			out.println("</p>");
		}
		out.println("</div>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
