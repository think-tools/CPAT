
import java.sql.*;
public class TestOracleConnection {
	static final String dbUrl = "jdbc:mysql://localhost:3306/mysql";
	static final String username = "root";
	static final String password = "mypassword";

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = DriverManager.getConnection(dbUrl, username, password);
		System.out.println("Connection Successful");
	}

}
